# Trader Behavior Insights Notebook

Run the notebook in Jupyter.

Add datasets inside /data folder:
- historical_data.csv
- fear_greed.csv
